name_map = { "anm": "ANM", "cgnn": "CGNN", "emd": "EMD", "lingam": "LiNGAM", "pnl": "PNL", "qcd_function": "bQCD", "SlopeR": "Slope","lcube": "LCube", "igci": "IGCI", "loci": "LOCI"}
