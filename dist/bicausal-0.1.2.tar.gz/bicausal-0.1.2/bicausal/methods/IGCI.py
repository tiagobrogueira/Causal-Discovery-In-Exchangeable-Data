import numpy as np
from cdt.causality.pairwise import IGCI

# Instantiate the IGCI model
igci_model = IGCI()

def max_points():
    try:
        from bicausal.helpers.timers import get_max_points
        return get_max_points("IGCI")
    except ModuleNotFoundError:
        return None

def igci(d):
    x, y = d

    # Possibly subsample if too many points
    m = max_points()
    if m is not None and len(x) > m:
        idx = np.random.choice(len(x), m, replace=False)
        x = x[idx]
        y = y[idx]

    # Use the IGCI model to predict
    return igci_model.predict_proba((x, y))
